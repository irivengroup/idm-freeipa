# Lab Docker FreeIPA / Red Hat IdM sur Rocky Linux 9

Architecture: deux sites, deux subnets Docker bridge, un serveur IdM/DNS par site, deux clients auto-enrôlés par site, un node opérateur par site, reverse proxy Nginx TCP/UDP/HTTP résilient.

## Démarrage rapide

```bash
cp .env.example .env   # si besoin
./scripts/00-host-prep-rocky9.sh
./scripts/01-up.sh
docker logs -f ipa-a
./scripts/02-post-config.sh
```

## Installation manuelle du node opérateur

```bash
docker exec -it a-operator-node bash
dnf -y install freeipa-client openssh-server oddjob-mkhomedir sssd sudo bind-utils
systemctl enable --now sshd
ipa-client-install -U --domain=iriven.lab --realm=iriven.lab --server=ipa-a.iriven.lab --principal=admin --password='ChangeMe_Adm1n!' --mkhomedir --force-join --no-ntp
```

Même logique sur `b-operator-node`, avec `--server=ipa-b.iriven.lab`.

## Vérifications

```bash
docker exec ipa-a ipa server-find
docker exec ipa-a ipa-replica-manage list
docker exec ipa-a ipa dnsrecord-find iriven.lab
docker exec a-client-01 getent passwd jdupont
docker exec a-client-01 ssh -V
```

## Ports IdM exposés par le proxy côté host

DNS 8053 TCP/UDP, HTTP 8080, HTTPS 8443, LDAP 8389, LDAPS 8636, Kerberos 8088 TCP/UDP, kpasswd 8464 TCP/UDP.

## Notes production

FreeIPA containerisé est excellent pour lab, pas pour production IdM critique. En production, privilégier VM/bare metal RHEL/Rocky avec DNS, NTP, sauvegardes, supervision, durcissement TLS, topologie de réplication validée et plan de restauration testé.
