#!/usr/bin/env bash
set -euo pipefail
source /etc/os-release
dnf -y install openssh-server freeipa-client oddjob oddjob-mkhomedir sssd sudo bind-utils krb5-workstation iproute procps-ng
systemctl enable --now sshd || /usr/sbin/sshd
DOMAIN="${DOMAIN:-iriven.lab}"
REALM="${REALM:-iriven.lab}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-ChangeMe_Adm1n!}"
SERVER="$(awk '/^nameserver/{print $2; exit}' /etc/resolv.conf)"
echo "$ADMIN_PASSWORD" | ipa-client-install -U \
  --domain="$DOMAIN" --realm="$REALM" \
  --server="$(dig +short -x "$SERVER" | sed 's/\.$//' | head -1)" \
  --principal=admin --password="$ADMIN_PASSWORD" \
  --mkhomedir --force-join --no-ntp || true
tail -f /dev/null
