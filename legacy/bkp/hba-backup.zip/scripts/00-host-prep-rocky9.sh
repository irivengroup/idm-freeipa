#!/usr/bin/env bash
set -euo pipefail
sudo dnf -y install dnf-plugins-core git bind-utils
sudo dnf config-manager --add-repo https://download.docker.com/linux/rhel/docker-ce.repo
sudo dnf -y install docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo systemctl enable --now docker
sudo setsebool -P container_manage_cgroup 1 || true
if ! grep -q userns-remap /etc/docker/daemon.json 2>/dev/null; then
  echo '{ "userns-remap": "default" }' | sudo tee /etc/docker/daemon.json
  sudo systemctl restart docker
fi
sudo firewall-cmd --permanent --add-port={8053/tcp,8053/udp,8080/tcp,8443/tcp,8389/tcp,8636/tcp,8088/tcp,8088/udp,8464/tcp,8464/udp} || true
sudo firewall-cmd --reload || true
