#!/usr/bin/env bash
set -euo pipefail
set -a; source .env; set +a
mkdir -p data/ipa-a data/ipa-b
docker compose up -d ipa-a
echo "Attendre que ipa-a soit healthy: docker logs -f ipa-a"
docker compose up -d ipa-b nginx-idm a-client-01 a-client-02 b-client-01 b-client-02 a-operator-node b-operator-node
