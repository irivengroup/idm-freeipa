#!/usr/bin/env bash
set -euo pipefail
set -a; source .env; set +a
docker exec -i ipa-a kinit admin <<< "$ADMIN_PASSWORD"
docker exec ipa-a ipa dnszone-add 128.1.168.192.in-addr.arpa. --name-server="$IPA_A_HOST." --admin-email=hostmaster.${DOMAIN}. --force || true
docker exec ipa-a ipa dnszone-add 192.1.168.192.in-addr.arpa. --name-server="$IPA_B_HOST." --admin-email=hostmaster.${DOMAIN}. --force || true
docker exec ipa-a ipa hostgroup-add site-a-hosts --desc="Hôtes site A" || true
docker exec ipa-a ipa hostgroup-add site-b-hosts --desc="Hôtes site B" || true
docker exec ipa-a ipa hbacrule-add allow_ssh_site_admins --servicecat=all --hostcat=all --desc="Lab SSH centralisé" || true
docker exec ipa-a ipa sudorule-add allow_wheel_all --cmdcat=all --hostcat=all || true
docker exec ipa-a ipa group-add site-admins --desc="Administrateurs lab" || true
docker exec ipa-a ipa sudorule-add-user allow_wheel_all --groups=site-admins || true
docker exec ipa-a ipa user-add jdupont --first=Jean --last=Dupont --password <<< "ChangeMe_User1!" || true
docker exec ipa-a ipa group-add-member site-admins --users=jdupont || true
docker exec ipa-a ipa topologysegment-find domain
docker exec ipa-a ipa dnsrecord-find "$DOMAIN" --structured | egrep 'Record name|SRV record|A record|Host name' || true
